#ifndef RES_H
#define RES_H

#include <Arduino.h>

const char INDEX_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>ESP32 DHT11</title>

<style>
body {
  font-family: Arial;
  background: #f2f2f2;
  text-align: center;
  margin-top: 40px;
}
.sensor {
  background: white;
  padding: 20px;
  margin: 10px;
  display: inline-block;
  border-radius: 10px;
  font-size: 22px;
}
.lamp {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #ccc;
  display: inline-block;
  margin: 10px;
}
.slider-box {
  background: white;
  padding: 20px;
  border-radius: 10px;
  display: inline-block;
  margin-top: 20px;
}
</style>
</head>

<body>

<h1>ESP32 DHT11 Sensor</h1>

<div class="sensor" id="temperature">Температура: -- °C</div>
<div class="sensor" id="humidity">Вологість: -- %</div>

<br>

<div class="lamp" id="blueLamp"></div>
<div class="lamp" id="redLamp"></div>

<br>

<div class="slider-box">
  Поріг температури: <b><span id="thresholdValue">--</span> °C</b><br><br>
  <input type="range" id="threshold" min="15" max="40" step="1" style="width:300px;">
</div>

<script>
const tempEl = document.getElementById("temperature");
const humEl = document.getElementById("humidity");
const slider = document.getElementById("threshold");
const thresholdValue = document.getElementById("thresholdValue");
const redLamp = document.getElementById("redLamp");
const blueLamp = document.getElementById("blueLamp");

async function update() {
  const res = await fetch("/sensor");
  const data = await res.json();

  tempEl.innerText = "Температура: " + (data.temperature ?? "--") + " °C";
  humEl.innerText = "Вологість: " + (data.humidity ?? "--") + " %";

  slider.value = data.threshold;
  thresholdValue.innerText = data.threshold;

  if (data.relay) {
    redLamp.style.background = "red";
    blueLamp.style.background = "#ccc";
  } else {
    blueLamp.style.background = "blue";
    redLamp.style.background = "#ccc";
  }
}

slider.addEventListener("input", () => {
  thresholdValue.innerText = slider.value;
  fetch(`/setThreshold?value=${slider.value}`);
});

setInterval(update, 1000);
update();
</script>

</body>
</html>
)rawliteral";

#endif

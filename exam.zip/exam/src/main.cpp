#include <Arduino.h>
#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <DHT.h>
#include "res.h"

static const char* AP_SSID = "ESP32 Roman";
static const char* AP_PASS = "1234567890";

#define DHTPIN 21
#define DHTTYPE DHT11
#define RELAY_PIN 22

AsyncWebServer server(80);
DHT dht(DHTPIN, DHTTYPE);

float temperatureThreshold = 26.0;

void startWifi() {
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  Serial.print("IP: ");
  Serial.println(WiFi.softAPIP());
}

void setupRoutes() {

  // Головна сторінка
  server.on("/", HTTP_GET, [](AsyncWebServerRequest* req) {
    req->send_P(200, "text/html", INDEX_HTML);
  });

  // Дані сенсора + поріг + стан реле
  server.on("/sensor", HTTP_GET, [](AsyncWebServerRequest* req) {
    float t = dht.readTemperature();
    float h = dht.readHumidity();
    bool relay = digitalRead(RELAY_PIN);

    String json = "{";
    json += "\"temperature\":";
    json += isnan(t) ? "null" : String(t);
    json += ",\"humidity\":";
    json += isnan(h) ? "null" : String(h);
    json += ",\"threshold\":";
    json += String(temperatureThreshold);
    json += ",\"relay\":";
    json += relay ? "true" : "false";
    json += "}";

    req->send(200, "application/json", json);
  });

  // Отримання порогу з веб-сторінки
  server.on("/setThreshold", HTTP_GET, [](AsyncWebServerRequest *req) {
    if (req->hasParam("value")) {
      temperatureThreshold = req->getParam("value")->value().toFloat();
      Serial.print("Новий поріг: ");
      Serial.println(temperatureThreshold);
      req->send(200, "text/plain", "OK");
    } else {
      req->send(400, "text/plain", "Missing value");
    }
  });

  server.begin();
}

void setup() {
  Serial.begin(9600);
  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, LOW);

  dht.begin();
  startWifi();
  setupRoutes();
}

void loop() {
  static unsigned long last = 0;

  if (millis() - last >= 1000) {
    last = millis();

    float t = dht.readTemperature();
    if (!isnan(t)) {
      if (t >= temperatureThreshold)
        digitalWrite(RELAY_PIN, HIGH);
      else
        digitalWrite(RELAY_PIN, LOW);
    }
  }
}
